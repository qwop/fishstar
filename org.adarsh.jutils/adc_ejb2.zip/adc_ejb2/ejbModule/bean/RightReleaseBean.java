package bean;

import ejb.Base;
import ejb.BeanDataHandler;

public class RightReleaseBean extends Base {
	
	
	public void method1() {
		BeanDataHandler handler = getHandler();
		try {
		} catch( Exception e ) {
			
		} finally {
			handler.release();
		}
	}
}
