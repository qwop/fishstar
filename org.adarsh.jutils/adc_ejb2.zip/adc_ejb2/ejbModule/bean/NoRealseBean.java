package bean;

import ejb.Base;
import ejb.BeanDataHandler;

public class NoRealseBean extends Base {
	
	
	public void method1() {
		BeanDataHandler handler = initialize();
		try {
		} catch( Exception e ) {
			
		} finally {
		}
	}
}
