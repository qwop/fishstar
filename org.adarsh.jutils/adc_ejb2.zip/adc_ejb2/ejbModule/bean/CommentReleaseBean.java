package bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ejb.Base;
import ejb.BeanDataHandler;

public class CommentReleaseBean extends Base {
	
	
	public void commentReleaseBeanMethod() {
		BeanDataHandler handler = getHandler();
		try {
		} catch( Exception e ) {
			
		} finally {
			// handler.release(); 
		handler = null; /*
			
			
			handler.release			
			(								)				 ;
			*/
		}
	}
	
	public static void main(String[] args) {
		final String value = "BeanDataHandler handler = getHandler();//\r\n handler.release();";
		String wrongValue = "BeanDataHandler handler = getHandler(); \r\n //handler.release          (            );";
		String wrongValue1 = "BeanDataHandler handler = getHandler(); /*\r\n handler.release          (            );*/";
		String value1 = "this is a test";
//		System.out.println( value.matches( "^.+//\\s*\\w+\\.release\\(\\).+$" ) );
		
		Matcher m = Pattern.compile( "//([ \\t\\f]*)\\w+\\.release\\s*\\(\\s*\\)", Pattern.DOTALL ).matcher( wrongValue );
		m = Pattern.compile( "/\\*\\s*\\w+\\.release\\s*\\(\\s*\\).+\\*/", Pattern.DOTALL ).matcher( wrongValue1 );
		System.out.println ( wrongValue1 );
		System.out.println ( m.find() );
	}
}
