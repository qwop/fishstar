package ejb;

public class BeanDataHandler {
	public void release() {
		
	}
}
