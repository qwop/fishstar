package ejb;

public class Base {
	protected BeanDataHandler getHandler() {
		return new BeanDataHandler();
	}
	
	public BeanDataHandler initialize() {
		return new BeanDataHandler();
	}
}
