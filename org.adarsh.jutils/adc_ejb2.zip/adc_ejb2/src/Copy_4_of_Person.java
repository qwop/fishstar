
public class Copy_4_of_Person {
	private int intVariable;
	private String strVariable;
	
	public double doubleVariable;
	public Copy_4_of_Person selfVariable;
	
	
	public void publicMethod() {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			
		}
	}
	
	
	private void privateMethod() {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			
		}
	}


	
}
