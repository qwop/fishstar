
public class CopyOfPerson {
	private int intVariable;
	private String strVariable;
	
	public double doubleVariable;
	public CopyOfPerson selfVariable;
	
	
	public void publicMethod() {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			
		}
	}
	
	
	private void privateMethod() {
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			
		}
	}


	
}
